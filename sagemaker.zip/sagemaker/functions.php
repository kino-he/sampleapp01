<?php
/**
 * スクリプトとスタイルを適切にエンキューする
 */
function theme_name_scripts() {
    wp_enqueue_style('reset_style',get_theme_file_uri('/assets/css/ress.css'), array(), date('YmdGis',filemtime( get_theme_file_path( '/assets/css/ress.css' ))));
    wp_enqueue_style('_style',get_theme_file_uri('/style.css'), array(), date('YmdGis',filemtime( get_theme_file_path( '/style.css' ))));
    wp_enqueue_style('main_style',get_theme_file_uri('/assets/css/main.css'), array(), date('YmdGis',filemtime( get_theme_file_path( '/assets/css/main.css' ))));
    wp_enqueue_style('mainsp_style',get_theme_file_uri('/assets/css/main_sp.css'), array(), date('YmdGis',filemtime( get_theme_file_path( '/assets/css/main_sp.css' ))));

    wp_deregister_script('jquery');
    wp_enqueue_script('jquery','//code.jquery.com/jquery-3.6.3.min.js');
    wp_enqueue_script('main-script',get_theme_file_uri('/assets/js/main.js'), array(), date('YmdGis',filemtime( get_theme_file_path( '/assets/js/main.js' ))));
}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );

/**
*<title>タグを出力する
*/
add_theme_support('title-tag');
?>