<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <meta name="description" content="テキストテキストテキストテキストテキストテキストテキスト">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo get_theme_file_uri(); ?>/assets/image/sample.ico">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <div class="container">
        <?php wp_body_open(); ?>
        <header id="header">

        </header>

        <h1>データ分析プラットフォーム機械学習環境</h1>
        <div class="logo">
            <img src="<?php echo get_theme_file_uri(); ?>/assets/image/snowflake.png" alt="画像の説明">
        </div>
        <div class="input-form">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="text" name="input_data" placeholder="データを入力してください" required>
                <div class="submit-button">
                    <input type="submit" value="エンター">
                </div>
            </form>
        </div>
    </div>
	<?php
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$host = 'ls-77415d74698b7a13def32e9025f9ad0729035a9a.ckvtftba1lxp.ap-northeast-1.rds.amazonaws.com';
		$username = 'dbmasteruser';
		$password = 'V|DZ8P9~U94F8s2b^_?yr>h`]h8(hf^$';
		$database = 'sagemaker_linksite';
	
	
		$connection = new mysqli($host, $username, $password, $database);
		if($connection->connect_error){
			die("接続エラー：" . $connection->connect_error);
		}
		$query = "SELECT * FROM employee";
		$result = $connection->query($query);
	
		if($result->num_rows > 0){
			while($row = $result->fetch_assoc()){
				echo "従業員番号:" . $row["employeeId"];
			}
		}else{
			echo "該当なし";
		}
		$connection->close();
	}
	?>
</body>
</html>