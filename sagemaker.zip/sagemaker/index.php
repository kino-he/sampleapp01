<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <meta name="description" content="テキストテキストテキストテキストテキストテキストテキスト">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo get_theme_file_uri(); ?>/assets/image/sample.ico">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <header>
        <img src="<?php echo get_theme_file_uri(); ?>/assets/image/amazon_image.png" alt="Header Image">
    </header>
	<div class="block1">
		<img src="<?php echo get_theme_file_uri(); ?>/assets/image/sagemaker_image.jpg" alt="Main Image">
	</div>
    <div class="block2">
        <div class="text-container">
            <p>データ分析プラットフォーム</p>
			<p>機械学習環境</p>
			<p>(Sagemaker Studio/Canvas)</p>
			<p><br></p>
            <form>
                <input type="text" placeholder="従業員番号(7桁)">
                <br>
                <button type="submit">ボタン</button>
            </form>
        </div>
    </div>
	<div class="block3">
		<div class="text-container">
            <p>プラットフォーマー事業部</p>
			<p>(smscxx001)</p>
        </div>
        <div class="studio-container">
            <img src="<?php echo get_theme_file_uri(); ?>/assets/image/sagemakerstudio_image.png" alt="Sagemaker Studio">
	    </div>
		<div class="canvas-container">
            <img src="<?php echo get_theme_file_uri(); ?>/assets/image/Sagemakercanvas_image.png" alt="Sagemaker Canvas">
        </div>
	</div>
</body>
</html>