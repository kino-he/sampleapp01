<!DOCTYPE html>
<html lang="ja">

<head>
    <meta charset="utf-8">
    <meta name="description" content="Sagemaker linksite">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?php echo get_theme_file_uri(); ?>/assets/image/sample.ico">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
    <header>
        <img src="<?php echo get_theme_file_uri(); ?>/assets/image/amazon_image.png" alt="Header Image">
    </header>
	<div class="block1">
		<img src="<?php echo get_theme_file_uri(); ?>/assets/image/sagemaker_image.jpg" alt="Main Image">
	</div>
    <div class="block2">
        <div class="text-container">
            <p>データ分析プラットフォーム</p>
			<p>機械学習環境</p>
			<p>(Sagemaker Studio/Canvas)</p>
			<p><br></p>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <input type="text" name="input_data" placeholder="従業員番号(7桁)">
                <br>
                <button type="submit">ボタン</button>
            </form>
        </div>
    </div>
	<?php 
	if($_SERVER["REQUEST_METHOD"] == "POST"){
		$host = 'ls-77415d74698b7a13def32e9025f9ad0729035a9a.ckvtftba1lxp.ap-northeast-1.rds.amazonaws.com';
		$username = 'dbmasteruser';
		$password = 'V|DZ8P9~U94F8s2b^_?yr>h`]h8(hf^$';
		$database = 'sagemaker_linksite';
		
		$connection = new mysqli($host, $username, $password, $database);
		if($connection->connect_error){
			die("接続エラー：" . $connection->connect_error);
		}
		$query = "SELECT * FROM employee WHERE Employee_id = " . $_POST["input_data"] ;
		$result = $connection->query($query);
		if($result->num_rows > 0){
			while($row = $result->fetch_assoc()){
				$Project_id = $row["Project_id"];
				$Domain_id = $row["Domain_id"];
				$Sagemaker_url = "https://{$Domain_id}.studio.ap-northeast-1.sagemaker.aws/";
				$Canvas_url = "https://{$Domain_id}.studio.ap-northeast-1.sagemaker.aws/canvas/default/";
				
				echo "<div class=\"block3\">";
				echo "<div class=\"text-container\">";
				echo "<p>({$Project_id})</p>";
        		echo "</div>";
        		echo "<div class=\"studio-container\">";
				$asset_pass = get_theme_file_uri();
				echo "<a href=\"{$Sagemaker_url}\"><img src=\"{$asset_pass}/assets/image/sagemakerstudio_image.png\" alt=\"SagemakerStudio\"></a>";
	    		echo "</div>";
				echo "<div class=\"canvas-container\">";
            	echo "<a href=\"{$Canvas_url}\"><img src=\"{$asset_pass}/assets/image/Sagemakercanvas_image.png\" alt=\"SagemakerCanvas\"></a>";
        		echo "</div>";
				echo "</div>";
			}
		} else {
			echo "<div class=\"block3\">";
			echo "<div class=\"text-container\">";
			echo "<p>ドメイン未登録です。サポートへご確認ください。</p>";
        	echo "</div>";
			echo "</div>";
		}
	}
	?>
	<script>
        const studioContainer = document.querySelector('.studio-container');
        const canvasContainer = document.querySelector('.canvas-container');

        studioContainer.addEventListener('mouseenter', () => {
            studioContainer.querySelector('img').classList.add('highlight');
        });

        studioContainer.addEventListener('mouseleave', () => {
            studioContainer.querySelector('img').classList.remove('highlight');
        });

        canvasContainer.addEventListener('mouseenter', () => {
            canvasContainer.querySelector('img').classList.add('highlight');
        });

        canvasContainer.addEventListener('mouseleave', () => {
            canvasContainer.querySelector('img').classList.remove('highlight');
        });
    </script>
	
<?php wp_footer(); ?>
</body>
</html>